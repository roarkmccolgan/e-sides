title: Resources
template: resources/index
mount: resources
id: 64902db9-06c0-4df0-af72-e75004507405
