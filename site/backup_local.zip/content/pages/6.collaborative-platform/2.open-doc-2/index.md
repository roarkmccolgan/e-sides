is_hidden: true
description: This is the summary for the second doc
doc_url: 'https://docs.google.com/document/d/1vkpioBgKpjduMygfGlLGA_OPlzsXsW_Vz_HsJTuudQI/edit?usp=sharing&embedded=true'
url: 'https://docs.google.com/document/d/1vkpioBgKpjduMygfGlLGA_OPlzsXsW_Vz_HsJTuudQI/edit?usp=sharing&embedded=true'
title: Open Doc 2
template: opendoc/opendoc
fieldset: Open Doc
id: de1a6be8-f921-4436-8f22-3061d77c7d82
