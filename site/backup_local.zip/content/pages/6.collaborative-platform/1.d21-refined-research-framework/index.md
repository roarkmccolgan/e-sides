is_hidden: true
description: This is the summary for the first doc
doc_url: 'https://docs.google.com/document/d/1gc0jcxvESQ_W4gIaLwXk-8U5xTqc3QoSesx7FiSetrg/edit?usp=sharing&embedded=true'
url: 'https://docs.google.com/document/d/1gc0jcxvESQ_W4gIaLwXk-8U5xTqc3QoSesx7FiSetrg/edit?usp=sharing&embedded=true'
title: D2.1 Refined Research Framework
template: opendoc/opendoc
fieldset: Open Doc
id: ea8d5b08-4daa-4339-b5ee-a256a3a2efd6
