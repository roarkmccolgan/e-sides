title: Collaborative Platform
template: opendoc/index
id: fe50acbd-681e-417b-8e24-3166070f0c57
