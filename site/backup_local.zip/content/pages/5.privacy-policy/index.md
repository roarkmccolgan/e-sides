---
title: Privacy Policy
is_hidden: true
id: 6856e89f-d096-4e00-bc1d-27d0a89ac503
---
**Personal Data**

As this online website collects and further processes personal data, the General Data Protection Regulation (GDPR) (Regulation (EU) 2016/679) of 24 May 2016 on the protection of individuals with regard to the processing of personal data by the Community institutions and bodies and on the free movement of such data will be applied.

Although you can browse through e-SIDES website without giving any information about yourself, we do require certain personal information in order to grant you access to some parts of the portal. We treat this information according to the privacy policy notice.

Should you have any queries about the processing of your personal data, both regarding access to data and rectification of this data, you are invited to send your request to info[at]e-sides.eu.

**Privacy Policy Notice** 

When you register to become a member of the e-SIDES community or subscribe to our newsletter and updates, we save your private data in our systems.

The information details we collect for the purposes of registering with a profile on e-SIDES are: full name, organization name, job title, country and email address. This information is collected and safely stored in order to provide the user access to the community, newsletter subscription, contribution of content in particular cases (news, events etc.).

We take high security measures to safeguard the information against possible misuse or un-authorized access.